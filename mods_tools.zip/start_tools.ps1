$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$command = "cd `"$scriptDir`"; Start-Process `"$scriptDir\__tools\UAssetGUI\UAssetGUI-experimental.exe`""
Start-Process powershell -ArgumentList "-NoExit", "-Command", $command
